## bspwm auto rice [bspar]
an automatice ricing script for bspwm (my dots)

## Installation
```pip install bspwm-auto-rice```

## Usage
for help:
```bspar --help```
and 
```bspar <command> --help```
example:
```bspar set --help```