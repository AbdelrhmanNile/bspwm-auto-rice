## bspwm auto rice [bspar]
an automatice ricing script for bspwm (my dots)

ONLY WORKS ON ARCH BASED DISTROS

## demo
[Demo](https://i.imgur.com/VBXp4yK.mp4)

## Installation
```pip install bspwm-auto-rice```

## Usage
for help:
```bspar --help```
and 
```bspar <command> --help```
example:
```bspar set --help```